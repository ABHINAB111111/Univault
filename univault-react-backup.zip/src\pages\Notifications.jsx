import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Bell, 
  ShoppingBag, 
  Key, 
  Search, 
  Info, 
  CheckCircle2, 
  X,
  MoreVertical
} from 'lucide-react';
import { StatusBar, BottomNav } from '../components/Layout';

const notifRoutes = {
  sale: '/marketplace',
  rental: '/vault',
  found: '/lost-found',
  system: '/settings',
  award: '/rewards',
};

const initialNotifications = [
  { id: 1, type: 'sale', title: 'Item Sold!', desc: '"Physics Vol. 2" was purchased by Rohan M.', time: '2m ago', unread: true, icon: ShoppingBag, color: 'text-teal-600', bg: 'bg-teal-50' },
  { id: 2, type: 'rental', title: 'Due Soon', desc: 'Camera Kit is due for return by 4 PM tomorrow.', time: '1h ago', unread: true, icon: Key, color: 'text-amber-600', bg: 'bg-amber-50' },
  { id: 3, type: 'found', title: 'Match Found!', desc: 'Someone reported finding "Blue Keys" in Library.', time: '3h ago', unread: false, icon: Search, color: 'text-[#1C3F6E]', bg: 'bg-[#1C3F6E]/5' },
  { id: 4, type: 'system', title: 'Security Alert', desc: 'New login detected from a Chrome browser.', time: 'Yesterday', unread: false, icon: Info, color: 'text-slate-500', bg: 'bg-slate-50' },
  { id: 5, type: 'award', title: 'Badge Earned!', desc: 'You received the "Trusted Seller" badge.', time: '2 days ago', unread: false, icon: CheckCircle2, color: 'text-blue-600', bg: 'bg-blue-50' },
];

export default function Notifications() {
  const [notifications, setNotifications] = useState(initialNotifications);
  const navigate = useNavigate();

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, unread: false })));
  };

  const removeNotif = (id) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  return (
    <div className="flex flex-col h-full bg-[#F3F1ED] font-dm-sans overflow-hidden">
      <div className="bg-white pt-2 pb-5 px-6 shadow-sm border-b border-slate-100 z-40">
        <StatusBar />
        <div className="mt-2 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <ArrowLeft className="w-5 h-5 text-[#1C3F6E] cursor-pointer" onClick={() => navigate(-1)} />
            <h1 className="font-syne font-extrabold text-2xl text-[#1B1916] tracking-tight">Activity Feed</h1>
          </div>
          <button 
            onClick={markAllRead}
            className="text-[10px] font-bold text-[#1C3F6E] uppercase tracking-widest hover:underline"
          >
            Mark all read
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 pb-32 no-scrollbar overscroll-contain">
        {notifications.length > 0 ? (
          <div className="space-y-3">
            {notifications.map((n) => {
              const Icon = n.icon;
              return (
                <div 
                  key={n.id}
                  className={`relative bg-white rounded-3xl p-4 flex gap-4 shadow-[0_2px_12px_rgba(27,24,22,0.04)] transition-all transform hover:scale-[1.01] ${n.unread ? 'ring-2 ring-[#1C3F6E]/5' : ''} animate-fade`}
                >
                  {n.unread && (
                    <div className="absolute top-4 right-4 w-2 h-2 bg-[#C07828] rounded-full shadow-[0_0_8px_rgba(192,120,40,0.5)]"></div>
                  )}
                  
                  <div className={`w-12 h-12 rounded-2xl ${n.bg} flex items-center justify-center ${n.color} shrink-0`}>
                    <Icon size={24} />
                  </div>
                  
                  <div className="flex-1 min-w-0 pr-4">
                    <div className="flex justify-between items-start mb-0.5">
                      <h3 className="font-syne font-bold text-sm text-[#1B1916]">{n.title}</h3>
                      <span className="text-[9px] font-bold text-slate-300 uppercase">{n.time}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium leading-relaxed mb-3">
                      {n.desc}
                    </p>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => navigate(notifRoutes[n.type] || '/')}
                        className="px-3 py-1 bg-slate-50 rounded-lg text-[9px] font-bold text-[#1C3F6E] uppercase tracking-widest hover:bg-slate-100 transition-colors active:scale-95"
                      >
                        View Details
                      </button>
                      <button 
                        onClick={() => removeNotif(n.id)}
                        className="p-1 px-2 bg-slate-50 rounded-lg text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition-all"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center mt-20 text-center animate-fade">
            <div className="w-20 h-20 bg-white rounded-[32px] flex items-center justify-center text-slate-100 mb-6 shadow-sm">
              <Bell size={40} strokeWidth={1} />
            </div>
            <h3 className="font-syne font-extrabold text-lg text-[#1B1916] mb-1 tracking-tight">Inbox Empty</h3>
            <p className="text-xs font-medium text-slate-400 px-12 leading-relaxed italic">
              When there's campus activity, you'll see your alerts here.
            </p>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
