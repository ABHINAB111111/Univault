import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { 
  ShoppingBag, 
  Plus, 
  Search, 
  ChevronRight, 
  Star, 
  CheckCircle2, 
  MessageSquare, 
  ArrowRight, 
  Package, 
  Box,
  X,
  Smartphone,
  Book,
  Truck,
  Armchair,
  Shirt
} from 'lucide-react';
import { StatusBar, BottomNav } from '../components/Layout';
import { FormSheet } from '../components/Sheets';

const products = [
  { id:1, name:'Modern Architecture Textbook', cat:'Books', price:'₹450', badge:'available', img:'/assets/textbook.png', seller:'Meera R.', rating:4.8, desc:'Comprehensive architecture reference in perfect condition. No highlights or annotations. Ideal for 4th year students.' },
  { id:2, name:'TI-84 Plus Calculator', cat:'Tech', price:'₹820', badge:'available', img:'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&q=80', seller:'Nikhil V.', rating:4.6, desc:'Scientific graphing calculator, comes with fresh batteries and the original manual.' },
  { id:3, name:'Cannondale Mountain Bike', cat:'Transport', price:'₹3,100', badge:'sold', img:'https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?w=400&q=80', seller:'Arav S.', rating:5.0, desc:'21-speed mountain bike, recently serviced. Minor scuffs on the frame.' },
  { id:4, name:'Mechanical Keyboard (TKL)', cat:'Tech', price:'₹1,200', badge:'available', img:'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400&q=80', seller:'Sana K.', rating:4.7, desc:'Keychron K8 with brown switches. Comes with USB-C cable. Light use, excellent condition.' },
  { id:5, name:'IKEA Foldable Desk', cat:'Furniture', price:'₹600', badge:'reserved', img:'https://images.unsplash.com/photo-1593060974411-fa0812920251?w=400&q=80', seller:'Yash D.', rating:4.5, desc:'Compact fold-up desk, ideal for dorm rooms. Easy assembly included.' },
  { id:6, name:"Levi's Denim Jacket (M)", cat:'Clothing', price:'₹750', badge:'available', img:'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&q=80', seller:'Pooja N.', rating:4.9, desc:'Classic vintage look, worn 3-4 times. Dry cleaned and ready.' },
];

const categories = [
  { name: 'All', icon: Box },
  { name: 'Tech', icon: Smartphone },
  { name: 'Books', icon: Book },
  { name: 'Clothing', icon: Shirt },
  { name: 'Transport', icon: Truck },
  { name: 'Furniture', icon: Armchair },
];

const badgeColors = {
  available: 'bg-teal-50 text-teal-600',
  sold: 'bg-slate-100 text-slate-400',
  reserved: 'bg-amber-50 text-amber-600',
};

const listFields = [
  { key:'title', label:'Item Name', placeholder:'e.g. Physics Textbook Vol. 2', required:true },
  { key:'category', label:'Category', type:'select', options:['Tech', 'Books', 'Clothing', 'Transport', 'Furniture', 'Sports', 'Other'], required:true },
  { key:'price', label:'Price (₹)', type:'number', placeholder:'e.g. 450', required:true },
  { key:'condition', label:'Condition', type:'select', options:['Like New', 'Good', 'Fair', 'Needs Repair'], required:true },
  { key:'description', label:'Description', type:'textarea', placeholder:'Describe the item, any defects…', required:true },
  { key:'contact', label:'Contact Number', placeholder:'+91 99999 99999', required:true },
];

function DetailSheet({ item, onClose }) {
  const [step, setStep] = useState('view');

  if (step === 'success') {
    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[300] flex items-center justify-center p-6 animate-fade">
        <div className="bg-white w-full max-w-sm rounded-[32px] p-8 text-center shadow-2xl animate-pop">
          <div className="w-20 h-20 bg-teal-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="text-teal-500" size={40} />
          </div>
          <h2 className="font-syne font-extrabold text-2xl text-[#1B1916] mb-3 leading-tight tracking-tight">Purchase Requested!</h2>
          <p className="font-dm-sans text-sm text-slate-500 leading-relaxed mb-8 px-2">
            Your request for <span className="font-bold text-[#1B1916]">{item.name}</span> has been sent to <span className="font-bold text-[#1C3F6E]">{item.seller}</span>. 
          </p>
          <button 
            onClick={onClose} 
            className="w-full py-4 rounded-2xl bg-[#1B1916] text-white font-syne font-bold text-sm shadow-xl active:scale-95 transition-all"
          >
            Back to Marketplace
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-[300] flex items-end animate-fade" onClick={onClose}>
      <div 
        className="bg-white w-full rounded-t-[32px] animate-slideUp max-h-[95%] overflow-y-auto no-scrollbar shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="w-12 h-1.5 bg-slate-100 rounded-full mx-auto my-4" />
        
        {step === 'confirm' ? (
          <div className="px-6 pt-2 pb-12 text-center">
            <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-6 text-[#1C3F6E]">
              <ShoppingBag size={32} />
            </div>
            <h2 className="font-syne font-extrabold text-2xl text-[#1B1916] mb-2">Confirm Purchase?</h2>
            <p className="text-sm font-medium text-slate-400 mb-6">{item.name}</p>
            
            <div className="font-syne font-extrabold text-4xl text-[#C07828] mb-8 tracking-tight">{item.price}</div>
            
            <div className="bg-slate-50 rounded-2xl p-5 mb-10 text-left">
              <p className="text-xs text-slate-500 font-medium leading-relaxed italic opacity-80">
                This sends a <span className="font-bold">direct purchase request</span> to {item.seller}. 
                Payment and inspection are handled in person during the campus meeting.
              </p>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => setStep('view')} 
                className="flex-1 py-4 rounded-xl border border-slate-200 font-syne font-bold text-sm text-slate-500 active:scale-95 transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={() => setStep('success')} 
                className="flex-[1.5] py-4 rounded-xl bg-[#1C3F6E] text-white font-syne font-bold text-sm shadow-xl shadow-blue-900/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                Confirm Purchase <ArrowRight size={18} />
              </button>
            </div>
          </div>
        ) : (
          <div className="px-5 pt-2 pb-12">
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] mb-6 shadow-sm group">
              <img src={item.img} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className={`absolute top-4 right-4 px-3 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-widest ${badgeColors[item.badge]}`}>
                {item.badge}
              </div>
            </div>

            <div className="flex justify-between items-start mb-6 gap-4">
              <div className="flex-1">
                <h2 className="font-syne font-extrabold text-2xl text-[#1B1916] leading-tight mb-2 tracking-tight">{item.name}</h2>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-md">
                    <Star className="text-amber-400 fill-amber-400" size={14} />
                    <span className="text-xs font-bold text-[#1B1916]">{item.rating}</span>
                  </div>
                  <span className="text-slate-300">·</span>
                  <p className="text-xs font-medium text-slate-400">Listed by <span className="text-[#1C3F6E] font-bold">{item.seller}</span></p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Price</p>
                <div className="font-syne font-extrabold text-2xl text-[#C07828] tracking-tight">{item.price}</div>
              </div>
            </div>

            <div className="bg-[#F3F1ED] rounded-2xl p-5 mb-8">
              <p className="text-sm text-[#1B1916] font-medium leading-relaxed opacity-70 italic">{item.desc}</p>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={onClose} 
                className="flex-1 py-4 rounded-xl border border-slate-200 font-syne font-bold text-sm text-slate-600 flex items-center justify-center gap-2 hover:bg-slate-50 active:scale-95 transition-all"
              >
                <MessageSquare size={18} className="text-[#1A7A6A]" /> Message
              </button>
              <button 
                disabled={item.badge !== 'available'}
                onClick={() => item.badge === 'available' && setStep('confirm')}
                className={`flex-[1.5] py-4 rounded-xl font-syne font-bold text-sm shadow-xl active:scale-95 transition-all text-white
                  ${item.badge === 'available' ? 'bg-[#1C3F6E] shadow-blue-900/20' : 'bg-slate-200 text-slate-400 shadow-none pointer-events-none'}`}
              >
                {item.badge === 'sold' ? 'Sold Out' : item.badge === 'reserved' ? 'Reserved' : 'Purchase Item'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Marketplace() {
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const initialSearch = urlParams.get('q') || '';
  const shouldList = urlParams.get('list') === '1';

  const [activeCat, setActiveCat] = useState('All');
  const [search, setSearch] = useState(initialSearch);
  const [selected, setSelected] = useState(null);
  const [showList, setShowList] = useState(shouldList);

  const filtered = products.filter(p =>
    (activeCat === 'All' || p.cat === activeCat) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-[#F3F1ED] font-dm-sans overflow-hidden">
      {/* ── Liquid Glass Header ──────────────────────────────────── */}
      <div className="relative overflow-hidden flex-shrink-0 pt-2 pb-5 px-6" style={{
        background: 'linear-gradient(165deg, #162B50 0%, #0F1D35 40%, #1A2D52 70%, #0F1D35 100%)',
        boxShadow: '0 12px 40px rgba(0,0,0,0.3)',
      }}>
        {/* Liquid glass ambient orbs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-10 -left-10 w-48 h-48 rounded-full opacity-20" style={{
            background: 'radial-gradient(circle, rgba(120,255,200,0.3) 0%, transparent 70%)',
            filter: 'blur(30px)',
            animation: 'liquidFloat 8s ease-in-out infinite',
          }} />
          <div className="absolute bottom-10 -right-10 w-40 h-40 rounded-full opacity-30" style={{
            background: 'radial-gradient(circle, rgba(120,180,255,0.4) 0%, transparent 70%)',
            filter: 'blur(40px)',
            animation: 'liquidFloat 10s ease-in-out infinite reverse',
          }} />
          <div className="absolute top-0 left-0 right-0 glass-rim-light opacity-30" />
        </div>

        <StatusBar white />
        
        <div className="relative z-10 mt-2">
          <div className="flex items-center justify-between mb-5">
            <h1 className="font-bold text-[26px] text-white leading-none tracking-tight drop-shadow-lg">Marketplace</h1>
            <button 
              onClick={() => setShowList(true)} 
              className="flex items-center gap-2 px-4 py-2 rounded-xl glass-liquid text-white font-bold text-[10px] uppercase tracking-widest hover:bg-white/20 active:scale-95 transition-all"
            >
              <Plus size={14} strokeWidth={3} /> ADD NEW
            </button>
          </div>
          
          <div className="relative mb-5 group">
            <div className="absolute inset-0 rounded-2xl glass-liquid glass-inner-shadow" />
            <div className="absolute -top-[1px] left-8 right-8 glass-rim-light opacity-40 blur-[1px] rounded-full" />
            
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40 group-focus-within:text-white/70 transition-colors z-10" size={16} />
            <input 
              placeholder="Search items…" 
              value={search} 
              onChange={e => setSearch(e.target.value)} 
              className="relative w-full py-3.5 pl-11 pr-12 text-sm bg-transparent border-transparent text-white placeholder-white/40 outline-none z-10 font-medium"
            />
            {search && (
              <button 
                onClick={() => setSearch('')} 
                className="absolute right-3 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors z-20"
              >
                <X size={14} className="text-white/60" />
              </button>
            )}
          </div>

          <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1">
            {categories.map((c) => {
              const Icon = c.icon;
              return (
                <button 
                  key={c.name} 
                  onClick={() => setActiveCat(c.name)} 
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-[10.5px] uppercase tracking-widest transition-all whitespace-nowrap border ${
                    activeCat===c.name 
                    ? 'bg-white text-[#0F1D35] border-white shadow-lg' 
                    : 'bg-white/5 text-white/40 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <Icon size={12} /> {c.name}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 pb-32 no-scrollbar animate-fade overscroll-contain">
        {search && (
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-5 ml-1">
            Found {filtered.length} {filtered.length === 1 ? 'product' : 'products'} for "{search}"
          </p>
        )}
        
        <div className="flex flex-col gap-3">
          {filtered.map((item, i) => (
            <div 
              key={item.id} 
              onClick={() => setSelected(item)}
              className="bg-white rounded-2xl p-3 shadow-[0_2px_14px_rgba(27,25,22,0.05)] border border-[#EEEEEC] flex items-stretch gap-4 cursor-pointer group hover:shadow-lg hover:-translate-y-0.5 transition-all active:scale-95 animate-fade"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div className="w-24 h-24 flex-shrink-0 overflow-hidden relative rounded-xl">
                <img src={item.img} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className={`absolute bottom-0 left-0 w-full text-center py-0.5 text-[8px] font-black uppercase tracking-widest backdrop-blur-md bg-white/70 ${badgeColors[item.badge]}`}>
                  {item.badge}
                </div>
              </div>
              <div className="flex-1 py-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-[14px] text-[#111111] leading-tight line-clamp-2">{item.name}</h3>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-[10px] text-slate-400 font-medium">{item.seller}</p>
                    <div className="flex items-center gap-1">
                      <Star className="text-amber-400 fill-amber-400" size={10} />
                      <span className="text-[10px] font-bold text-slate-500">{item.rating}</span>
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <p className="syne-wide text-[16px] text-[#C07828] leading-none">{item.price}</p>
                  <div className="w-7 h-7 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                    <ChevronRight size={14} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center mt-12 text-center animate-fade">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mb-6">
              <ShoppingBag size={40} strokeWidth={1} />
            </div>
            <h3 className="font-syne font-extrabold text-lg text-[#1B1916] mb-2 tracking-tight">Nothing found</h3>
            <p className="text-sm font-medium text-slate-400 px-8 leading-relaxed italic">Try a different category or search term</p>
          </div>
        )}
      </div>

      {selected && <DetailSheet item={selected} onClose={() => setSelected(null)} />}
      
      {showList && (
        <FormSheet 
          title="📦 List an Item" 
          fields={listFields} 
          submitLabel="Publish Listing" 
          onClose={() => setShowList(false)} 
        />
      )}

      <BottomNav />
    </div>
  );
}
