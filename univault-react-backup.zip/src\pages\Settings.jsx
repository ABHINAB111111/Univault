import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Moon, 
  Type, 
  Bell, 
  Mail, 
  MessageSquare, 
  Eye, 
  Shield, 
  Trash2, 
  ChevronRight, 
  ChevronLeft,
  Smartphone,
  Info
} from 'lucide-react';
import { StatusBar, Toast } from '../components/Layout';

const settingsGroups = [
  {
    section: 'Appearance',
    items: [
      { icon: Moon, label: 'Dark Mode', sub: 'Easy on the eyes at night', toggle: true, key: 'darkMode' },
      { icon: Type, label: 'Font Size', sub: 'Medium', toggle: false },
    ],
  },
  {
    section: 'Notifications',
    items: [
      { icon: Bell, label: 'Push Alerts', sub: 'Rental & lost item updates', toggle: true, key: 'push' },
      { icon: Mail, label: 'Email Digest', sub: 'Weekly summary', toggle: true, key: 'email' },
      { icon: MessageSquare, label: 'Chat Alerts', sub: 'New messages', toggle: true, key: 'chat' },
    ],
  },
  {
    section: 'Privacy & Security',
    items: [
      { icon: Eye, label: 'Profile Visibility', sub: 'Campus-only', toggle: false },
      { icon: Shield, label: 'Two-Factor Auth', sub: 'Not enabled', toggle: true, key: '2fa' },
      { icon: Trash2, label: 'Delete Account', sub: 'Permanent action', toggle: false, danger: true },
    ],
  },
];

export default function Settings() {
  const navigate = useNavigate();
  const [toggles, setToggles] = useState({ darkMode: false, push: true, email: true, chat: true, '2fa': false });
  const [toast, setToast] = useState(null);

  const toggle = (key) => {
    setToggles(t => ({ ...t, [key]: !t[key] }));
    const label = key === 'darkMode' ? 'Dark Mode' : key;
    setToast(`${label} ${toggles[key] ? 'disabled' : 'enabled'}`);
  };

  return (
    <div className="flex flex-col h-full bg-[#F3F1ED] font-dm-sans overflow-hidden">
      {toast && <Toast message={toast} onDone={() => setToast(null)} />}

      <div className="bg-white flex-shrink-0 border-b border-slate-100 shadow-sm z-40">
        <StatusBar />
        <div className="flex items-center px-4 pt-1 pb-4">
          <button 
            onClick={() => navigate('/profile')} 
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-50 active:scale-90 transition-all text-slate-400"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="flex-1 text-center font-syne font-extrabold text-lg text-[#1B1916] tracking-tight mr-10">
            Settings
          </h1>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 no-scrollbar pb-32 overscroll-contain">
        <div className="bg-[#1B1916] rounded-[24px] p-5 mb-8 flex items-center justify-between shadow-xl shadow-black/10 transition-all active:scale-[0.98] cursor-pointer" onClick={() => toggle('darkMode')}>
          <div>
            <div className="font-syne font-extrabold text-[#FFFFFF] text-lg mb-1 tracking-tight">
              {toggles.darkMode ? 'Dark Mode On' : 'Light Mode On'}
            </div>
            <div className="text-xs text-slate-400 font-medium">Switch your visual experience</div>
          </div>
          <div className={`w-12 h-6 rounded-full relative transition-colors duration-300 ${toggles.darkMode ? 'bg-[#1C3F6E]' : 'bg-slate-700'}`}>
            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all duration-300 ${toggles.darkMode ? 'left-7' : 'left-1'}`} />
          </div>
        </div>

        {settingsGroups.map((group, groupIdx) => (
          <div key={group.section} className="mb-8 animate-fadeUp" style={{ animationDelay: `${groupIdx * 0.1}s` }}>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 px-1">{group.section}</p>
            <div className="bg-white rounded-[24px] overflow-hidden shadow-sm border border-slate-100">
              {group.items.map((item, i) => {
                const Icon = item.icon;
                return (
                  <div 
                    key={item.label}
                    onClick={() => item.toggle ? toggle(item.key) : item.danger ? setToast('Account deletion requires email confirmation!') : setToast(`${item.label} is synced with system settings.`)}
                    className={`flex items-center gap-4 px-5 py-4 cursor-pointer hover:bg-slate-50 active:bg-slate-100 transition-all
                      ${i < group.items.length - 1 ? 'border-b border-slate-50' : ''}`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0
                      ${item.danger ? 'bg-rose-50 text-rose-500' : 'bg-slate-50 text-slate-400'}`}>
                      <Icon size={20} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`font-syne font-extrabold text-[13px] ${item.danger ? 'text-rose-500' : 'text-[#1B1916]'}`}>
                        {item.label}
                      </div>
                      <div className="text-[10px] font-medium text-slate-400 truncate tracking-tight">{item.sub}</div>
                    </div>
                    {item.toggle ? (
                      <div className={`w-10 h-5 rounded-full relative transition-colors duration-300 ${toggles[item.key] ? 'bg-emerald-500' : 'bg-slate-200'}`}>
                        <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300 ${toggles[item.key] ? 'left-6' : 'left-1'}`} />
                      </div>
                    ) : (
                      <ChevronRight size={16} className="text-slate-300" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        <div className="mt-12 text-center pb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-50 border border-slate-100 mb-4">
            <Info size={12} className="text-slate-300" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Version 2.4.1 Production</span>
          </div>
          <p className="font-syne font-black text-[10px] text-slate-300 uppercase tracking-[0.2em] px-4">
            Designed for secure campus transactions
          </p>
        </div>
      </div>
    </div>
  );
}
