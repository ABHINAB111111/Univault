import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, ZoomIn, ZoomOut, ShieldCheck, Map as MapIcon, Info } from 'lucide-react';

const SPOTS = [
  { name: 'Central Library', icon: '📚', desc: 'Ground floor entrance — CCTV covered', safe: true, x: 120, y: 80 },
  { name: 'Main Cafeteria', icon: '🍽️', desc: 'Open 8AM–9PM, always crowded', safe: true, x: 200, y: 130 },
  { name: 'Block B Lobby', icon: '🏛️', desc: 'Near security desk, well lit', safe: true, x: 80, y: 150 },
  { name: 'Sports Complex Gate', icon: '⚽', desc: 'Daytime only, CCTV monitored', safe: true, x: 280, y: 170 },
  { name: 'Hostel C Main Gate', icon: '🏠', desc: '24h security, ideal for evening pickup', safe: true, x: 300, y: 80 },
  { name: 'Security Post 1', icon: '🛡️', desc: 'Main entrance security', safe: false, x: 160, y: 40 },
  { name: 'Security Post 2', icon: '🛡️', desc: 'Hostel block security', safe: false, x: 250, y: 120 },
  { name: 'You (Block C R412)', icon: '📍', desc: 'Your current location', you: true, x: 220, y: 90 },
];

const CampusMap = () => {
  const navigate = useNavigate();
  const canvasRef = useRef(null);
  const [scale, setScale] = useState(1);
  const [selectedSpot, setSelectedSpot] = useState(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;

    const draw = () => {
      ctx.clearRect(0, 0, W, H);

      // Background
      const bg = ctx.createLinearGradient(0, 0, W, H);
      bg.addColorStop(0, '#E8F4EE');
      bg.addColorStop(1, '#D8EEE4');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // Buildings
      const buildings = [
        { x: 30, y: 30, w: 80, h: 50, label: 'Library', color: '#B8D8F0' },
        { x: 160, y: 100, w: 70, h: 45, label: 'Cafeteria', color: '#F0D0A8' },
        { x: 30, y: 110, w: 50, h: 60, label: 'Block B', color: '#C8D8F8' },
        { x: 250, y: 140, w: 60, h: 40, label: 'Sports', color: '#B8E8C8' },
        { x: 260, y: 50, w: 75, h: 55, label: 'Hostel C', color: '#F0C8C8' },
      ];

      buildings.forEach(b => {
        ctx.fillStyle = b.color;
        ctx.strokeStyle = 'rgba(100,100,100,.1)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(b.x, b.y, b.w, b.h, 8);
        else ctx.rect(b.x, b.y, b.w, b.h);
        ctx.fill();
        ctx.stroke();
        
        ctx.fillStyle = 'rgba(28,63,110,0.4)';
        ctx.font = 'bold 10px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(b.label, b.x + b.w/2, b.y + b.h/2 + 4);
      });

      // Paths
      ctx.strokeStyle = 'rgba(180,160,120,.4)';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(110,55); ctx.lineTo(160,100); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(160,100); ctx.lineTo(230,100); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(80,170); ctx.lineTo(250,180); ctx.stroke();

      // Spots
      SPOTS.forEach(s => {
        const r = s.you ? 10 : 7;
        const color = s.you ? '#1C3F6E' : s.safe ? '#22C55E' : '#C07828';

        ctx.shadowColor = 'rgba(0,0,0,0.1)';
        ctx.shadowBlur = 4;
        ctx.beginPath();
        ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
        ctx.shadowBlur = 0;

        if (s.you) {
          ctx.beginPath();
          ctx.arc(s.x, s.y, r + 4, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(28,63,110,0.2)';
          ctx.lineWidth = 2;
          ctx.stroke();
        }

        ctx.font = '9px Arial';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#fff';
        ctx.fillText(s.icon, s.x, s.y + 3);
      });
    };

    draw();
  }, [scale]);

  return (
    <div className="bg-[#F3F1ED] dark:bg-slate-950 font-dm-sans text-on-surface antialiased min-h-screen flex flex-col">
      {/* Header */}
      <header className="fixed top-0 left-0 w-full z-50 bg-[#F3F1ED]/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="flex justify-between items-center px-6 h-14">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-600 dark:text-slate-400">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold font-syne tracking-tight text-[#1C3F6E] dark:text-blue-400">Safe Meetup Spots</h1>
          </div>
          <button className="p-2 text-[#1C3F6E] dark:text-blue-400 bg-white dark:bg-slate-900 rounded-xl shadow-sm">
            <MapPin className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 pt-14 pb-12 overflow-y-auto">
        <div className="px-6 py-6">
          {/* Map Section */}
          <div className="relative bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-xl border border-white dark:border-slate-800 mb-6 group">
            <div className="overflow-hidden bg-[#E8F4EE]">
              <canvas 
                ref={canvasRef} 
                width={360} 
                height={240} 
                className="w-full transition-transform duration-300"
                style={{ transform: `scale(${scale})` }}
              />
            </div>

            {/* Zoom Controls */}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <button onClick={() => setScale(s => Math.min(2, s + 0.2))} className="w-10 h-10 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md shadow-lg rounded-xl flex items-center justify-center text-[#1C3F6E] hover:bg-white active:scale-95 transition-all">
                <ZoomIn className="w-5 h-5" />
              </button>
              <button onClick={() => setScale(s => Math.max(0.8, s - 0.2))} className="w-10 h-10 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md shadow-lg rounded-xl flex items-center justify-center text-[#1C3F6E] hover:bg-white active:scale-95 transition-all">
                <ZoomOut className="w-5 h-5" />
              </button>
            </div>

            {/* Campus Label */}
            <div className="absolute bottom-4 left-4 px-3 py-1 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-lg shadow-sm border border-white/50 text-[10px] font-bold text-[#1C3F6E] uppercase tracking-widest font-syne flex items-center gap-2">
              <MapIcon className="w-3 h-3 text-teal-600" />
              University Main Campus
            </div>
          </div>

          {/* Legend */}
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-6 px-1">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-full shadow-sm border border-slate-100 dark:border-slate-800 whitespace-nowrap">
              <div className="w-2.5 h-2.5 rounded-full bg-[#22C55E]" />
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Safe Zones</span>
            </div>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-full shadow-sm border border-slate-100 dark:border-slate-800 whitespace-nowrap">
              <div className="w-2.5 h-2.5 rounded-full bg-[#1C3F6E]" />
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">You</span>
            </div>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-full shadow-sm border border-slate-100 dark:border-slate-800 whitespace-nowrap">
              <div className="w-2.5 h-2.5 rounded-full bg-[#C07828]" />
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Security</span>
            </div>
          </div>

          {/* List of Spots */}
          <h2 className="text-sm font-syne font-bold text-[#1C3F6E] dark:text-blue-400 mb-4 px-2 uppercase tracking-widest flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-600" />
            Recommended Exchange Spots
          </h2>
          <div className="space-y-3">
            {SPOTS.filter(s => s.safe).map((s, idx) => (
              <div 
                key={idx} 
                onClick={() => setSelectedSpot(s)}
                className={`bg-white dark:bg-slate-900 p-4 rounded-2xl flex items-center gap-4 transition-all duration-300 shadow-sm border border-slate-100 dark:border-slate-800 active:scale-95 cursor-pointer ${selectedSpot === s ? 'ring-2 ring-teal-500' : ''}`}
              >
                <div className="w-12 h-12 bg-teal-50 dark:bg-teal-900/20 rounded-xl flex items-center justify-center text-2xl shadow-inner italic">
                  {s.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-syne font-bold text-sm text-[#1C3F6E] dark:text-blue-400 uppercase tracking-tight">{s.name}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{s.desc}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-[9px] font-bold text-teal-600 bg-teal-50 dark:bg-teal-900/40 px-2 py-0.5 rounded uppercase tracking-tighter shadow-sm border border-teal-100 dark:border-teal-800">
                    Verified Safe
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 bg-[#1C3F6E] p-5 rounded-3xl text-white shadow-xl relative overflow-hidden group">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <Info className="w-4 h-4 text-orange-400" />
                <h4 className="text-xs font-bold uppercase tracking-[0.2em] font-syne">Exchange Safety Tips</h4>
              </div>
              <p className="text-xs text-blue-100/80 leading-relaxed mb-4">Always prefer well-lit, public areas with CCTV and active security presence for safe campus transactions.</p>
              <button className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-white/20">Learn More</button>
            </div>
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-white/5 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
          </div>
        </div>
      </main>
    </div>
  );
};

export default CampusMap;
