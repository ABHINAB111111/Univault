import React, { useState } from 'react';
import { 
  Key, 
  Plus, 
  Search, 
  ChevronRight, 
  Star, 
  CheckCircle2, 
  MessageSquare, 
  Calendar, 
  ArrowRight,
  Camera,
  Smartphone,
  Trophy,
  Music,
  Truck,
  Box,
  Clock,
  ShieldCheck,
  CalendarDays
} from 'lucide-react';
import { StatusBar, BottomNav } from '../components/Layout';
import { FormSheet } from '../components/Sheets';

const categories = [
  { name: 'All', icon: Box },
  { name: 'Cameras', icon: Camera },
  { name: 'Electronics', icon: Smartphone },
  { name: 'Sports', icon: Trophy },
  { name: 'Music', icon: Music },
  { name: 'Transport', icon: Truck },
];

const rentItems = [
  { id:1, name:'Sony Alpha A7 III Kit', category:'Cameras', price:'₹250/day', badge:'available', img:'/assets/camera.png', owner:'Rohit S.', rating:4.9, reviews:28, desc:'Full-frame mirrorless kit with 28-70mm lens. Comes with 2 batteries and a camera bag. Perfect for shoots and events.' },
  { id:2, name:'Epson Projector X3', category:'Electronics', price:'₹80/hr', badge:'available', img:'/assets/projector.png', owner:'Ananya M.', rating:4.7, reviews:15, desc:'3100 lumen brightness, HDMI + USB. Great for presentations or movie nights in the hostel.' },
  { id:3, name:'Trek Mountain Bike', category:'Sports', price:'₹120/day', badge:'rented', img:'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=400&q=80', owner:'Vikram P.', rating:4.8, reviews:42, desc:'21-speed mountain bike, recently serviced. Minor wear on handlebar grips. Returns on 5th April.' },
  { id:4, name:'DJI Mini 3 Drone', category:'Electronics', price:'₹400/day', badge:'available', img:'/assets/drone.png', owner:'Leena K.', rating:5.0, reviews:19, desc:'Lightweight 249g drone with 4K video. Requires campus permission to fly. Comes with 2 extra batteries.' },
  { id:5, name:'Yamaha Acoustic Guitar', category:'Music', price:'₹60/day', badge:'available', img:'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=400&q=80', owner:'Arjun D.', rating:4.6, reviews:11, desc:'Yamaha F280 with a strap and carry bag. Cleaned and freshly strung. Great for beginners.' },
  { id:6, name:'Canon EOS R50 Body', category:'Cameras', price:'₹300/day', badge:'rented', img:'/assets/camera.png', owner:'Priya S.', rating:4.9, reviews:33, desc:'Compact mirrorless body with 24.2MP sensor. Returns on 4th April. No lens included.' },
];

const badgeColors = {
  available: 'bg-teal-50 text-teal-600',
  rented: 'bg-amber-50 text-amber-600',
};

const listFields = [
  { key:'title', label:'Item Name', placeholder:'e.g. Sony Alpha A7 Kit', required:true },
  { key:'category', label:'Category', type:'select', options:['Cameras', 'Electronics', 'Sports', 'Music', 'Transport', 'Other'], required:true },
  { key:'price', label:'Your Price (e.g. ₹250/day)', placeholder:'₹ per hour or per day', required:true },
  { key:'deposit', label:'Security Deposit', placeholder:'e.g. ₹500', required:false },
  { key:'description', label:'Condition & Details', type:'textarea', placeholder:'Describe condition, accessories included…', required:true },
  { key:'contact', label:'Contact Number', placeholder:'+91 99999 99999', required:true },
];

function DetailSheet({ item, onClose }) {
  const [step, setStep] = useState('view');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  if (step === 'success') {
    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[300] flex items-center justify-center p-6 animate-fade">
        <div className="bg-white w-full max-w-sm rounded-[32px] p-8 text-center shadow-2xl animate-pop">
          <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <CalendarDays className="text-[#1C3F6E]" size={40} />
          </div>
          <h2 className="font-syne font-extrabold text-2xl text-[#1B1916] mb-3 leading-tight tracking-tight">Reservation Sent!</h2>
          <p className="font-dm-sans text-sm text-slate-500 leading-relaxed mb-6 px-2">
            Your request for <span className="font-bold text-[#1B1916]">{item.name}</span> was sent to <span className="font-bold text-[#1C3F6E]">{item.owner}</span>.
          </p>
          {fromDate && toDate && (
            <div className="bg-slate-50 rounded-xl px-4 py-3 mb-8 flex items-center justify-center gap-3 text-xs font-bold text-[#1C3F6E]">
              <Calendar size={14} /> {fromDate} — {toDate}
            </div>
          )}
          <button 
            onClick={onClose} 
            className="w-full py-4 rounded-2xl bg-[#1B1916] text-white font-syne font-bold text-sm shadow-xl active:scale-95 transition-all"
          >
            Go to My Bookings
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-[300] flex items-end animate-fade" onClick={onClose}>
      <div 
        className="bg-white w-full rounded-t-[32px] animate-slideUp max-h-[95%] overflow-y-auto no-scrollbar shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="w-12 h-1.5 bg-slate-100 rounded-full mx-auto my-4" />

        {step === 'confirm' ? (
          <div className="px-6 pt-2 pb-12">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-[#1C3F6E]">
                <CalendarDays size={24} />
              </div>
              <h2 className="font-syne font-extrabold text-xl text-[#1B1916] tracking-tight">Booking Details</h2>
            </div>
            
            <div className="flex gap-2 mb-5">
              {[
                { label: 'Today', from: new Date().toISOString().split('T')[0], to: new Date().toISOString().split('T')[0] },
                { label: '3 Days', from: new Date().toISOString().split('T')[0], to: new Date(Date.now() + 3*86400000).toISOString().split('T')[0] },
                { label: '1 Week', from: new Date().toISOString().split('T')[0], to: new Date(Date.now() + 7*86400000).toISOString().split('T')[0] },
              ].map(opt => (
                <button
                  key={opt.label}
                  onClick={() => { setFromDate(opt.from); setToDate(opt.to); }}
                  className={`flex-1 py-2 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all active:scale-95 border ${
                    fromDate === opt.from && toDate === opt.to
                    ? 'bg-[#1C3F6E] text-white border-[#1C3F6E]'
                    : 'bg-white text-slate-500 border-slate-200 hover:border-[#1C3F6E]/30'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">From</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-100 text-sm font-bold text-[#1B1916] outline-none focus:ring-2 focus:ring-blue-100 transition-all" 
                  value={fromDate} 
                  onChange={e => setFromDate(e.target.value)} 
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">To</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-100 text-sm font-bold text-[#1B1916] outline-none focus:ring-2 focus:ring-blue-100 transition-all" 
                  value={toDate} 
                  onChange={e => setToDate(e.target.value)} 
                />
              </div>
            </div>

            <div className="bg-slate-50 rounded-2xl p-5 mb-10 border border-slate-100/50">
              <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-200/50">
                <span className="text-sm font-bold text-[#1B1916]">Rate</span>
                <span className="text-sm font-extrabold text-[#C07828]">{item.price}</span>
              </div>
              <div className="flex items-center gap-3">
                <ShieldCheck size={18} className="text-[#1A7A6A] opacity-50 flex-shrink-0" />
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed italic">
                  Security deposit of <span className="font-bold text-slate-600">₹500</span> is required on handover.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => setStep('view')} 
                className="flex-1 py-4 rounded-xl border border-slate-200 font-syne font-bold text-sm text-slate-500 active:scale-95 transition-all"
              >
                Back
              </button>
              <button 
                disabled={!fromDate || !toDate}
                onClick={() => setStep('success')} 
                className={`flex-[1.5] py-4 rounded-xl font-syne font-bold text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 text-white
                  ${fromDate && toDate ? 'bg-[#1C3F6E] shadow-blue-900/20' : 'bg-slate-200 text-slate-400 shadow-none pointer-events-none'}`}
              >
                Confirm Request <ArrowRight size={18} />
              </button>
            </div>
          </div>
        ) : (
          <div className="px-5 pt-2 pb-12">
            <div className="relative rounded-2xl overflow-hidden aspect-video mb-6 shadow-sm group">
              <img src={item.img} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className={`absolute top-4 right-4 px-3 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-widest ${badgeColors[item.badge]}`}>
                {item.badge}
              </div>
            </div>

            <div className="flex justify-between items-start mb-6 gap-4">
              <div className="flex-1">
                <h2 className="font-syne font-extrabold text-2xl text-[#1B1916] leading-tight mb-2 tracking-tight">{item.name}</h2>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-md">
                    <Star className="text-amber-400 fill-amber-400" size={14} />
                    <span className="text-xs font-bold text-[#1B1916]">{item.rating}</span>
                  </div>
                  <span className="text-slate-300">·</span>
                  <p className="text-xs font-medium text-slate-400">{item.reviews} Reviews</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Owner</p>
                <div className="font-bold text-sm text-[#1C3F6E]">{item.owner}</div>
              </div>
            </div>

            <div className="bg-[#F3F1ED] rounded-2xl p-5 mb-8">
              <p className="text-sm text-[#1B1916] font-medium leading-relaxed opacity-70 italic">{item.desc}</p>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-8">
              {[
                { label: 'Price', val: item.price, icon: Clock },
                { label: 'Min Period', val: '1 Day', icon: Calendar },
                { label: 'Deposit', val: '₹500', icon: ShieldCheck }
              ].map((stat) => (
                <div key={stat.label} className="bg-white border border-slate-100 rounded-xl p-3 text-center shadow-sm">
                  <stat.icon size={16} className="mx-auto mb-2 text-slate-300" />
                  <div className="font-bold text-xs text-[#1B1916] mb-0.5">{stat.val}</div>
                  <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <button 
                onClick={onClose} 
                className="flex-1 py-4 rounded-xl border border-slate-200 font-syne font-bold text-sm text-slate-600 flex items-center justify-center gap-2 hover:bg-slate-50 active:scale-95 transition-all"
              >
                <MessageSquare size={18} className="text-[#1A7A6A]" /> Message
              </button>
              <button 
                disabled={item.badge !== 'available'}
                onClick={() => item.badge === 'available' && setStep('confirm')}
                className={`flex-[1.5] py-4 rounded-xl font-syne font-bold text-sm shadow-xl active:scale-95 transition-all text-white
                  ${item.badge === 'available' ? 'bg-[#1C3F6E] shadow-blue-900/20' : 'bg-slate-200 text-slate-400 shadow-none pointer-events-none'}`}
              >
                {item.badge === 'rented' ? '🔒 Unavailable' : '📅 Reserve Now'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Rent() {
  const [activeCat, setActiveCat] = useState('All');
  const [selected, setSelected] = useState(null);
  const [showList, setShowList] = useState(false);

  const filtered = activeCat === 'All' ? rentItems : rentItems.filter(i => i.category === activeCat);

  return (
    <div className="flex flex-col h-full bg-[#F3F1ED] font-dm-sans overflow-hidden">
      {/* ── Liquid Glass Header ──────────────────────────────────── */}
      <div className="relative overflow-hidden flex-shrink-0 pt-2 pb-5 px-6" style={{
        background: 'linear-gradient(165deg, #162B50 0%, #0F1D35 40%, #1A2D52 70%, #0F1D35 100%)',
        boxShadow: '0 12px 40px rgba(0,0,0,0.3)',
      }}>
        {/* Liquid glass ambient orbs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full opacity-25" style={{
            background: 'radial-gradient(circle, rgba(232,121,249,0.3) 0%, transparent 70%)',
            filter: 'blur(30px)',
            animation: 'liquidFloat 9s ease-in-out infinite',
          }} />
          <div className="absolute bottom-0 -left-10 w-44 h-44 rounded-full opacity-35" style={{
            background: 'radial-gradient(circle, rgba(120,255,200,0.2) 0%, transparent 70%)',
            filter: 'blur(45px)',
            animation: 'liquidFloat 11s ease-in-out infinite reverse',
          }} />
          <div className="absolute top-0 left-0 right-0 glass-rim-light opacity-30" />
        </div>

        <StatusBar white />
        
        <div className="relative z-10 mt-2">
          <div className="flex items-center justify-between mb-5">
            <h1 className="font-bold text-[26px] text-white leading-none tracking-tight drop-shadow-lg">Rentals</h1>
            <button 
              onClick={() => setShowList(true)} 
              className="flex items-center gap-2 px-4 py-2 rounded-xl glass-liquid text-white font-bold text-[10px] uppercase tracking-widest hover:bg-white/20 active:scale-95 transition-all"
            >
              <Plus size={14} strokeWidth={3} /> ADD NEW
            </button>
          </div>
          
          <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1">
            {categories.map((c) => {
              const Icon = c.icon;
              return (
                <button 
                  key={c.name} 
                  onClick={() => setActiveCat(c.name)} 
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-[10.5px] uppercase tracking-widest transition-all whitespace-nowrap border ${
                    activeCat===c.name 
                    ? 'bg-white text-[#0F1D35] border-white shadow-lg' 
                    : 'bg-white/5 text-white/40 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <Icon size={12} /> {c.name}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 pb-32 no-scrollbar animate-fade overscroll-contain">
        <div className="flex flex-col gap-3">
          {filtered.map((item, i) => (
            <div 
              key={item.id} 
              onClick={() => setSelected(item)}
              className="bg-white rounded-2xl p-3 shadow-[0_2px_14px_rgba(27,25,22,0.05)] border border-[#EEEEEC] flex items-stretch gap-4 cursor-pointer group hover:shadow-lg hover:-translate-y-0.5 transition-all active:scale-95 animate-fade"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div className="w-24 h-24 flex-shrink-0 overflow-hidden relative rounded-xl">
                <img src={item.img} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className={`absolute bottom-0 left-0 w-full text-center py-0.5 text-[8px] font-black uppercase tracking-widest backdrop-blur-md bg-white/70 ${badgeColors[item.badge]}`}>
                  {item.badge}
                </div>
              </div>
              <div className="flex-1 py-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-[14px] text-[#111111] leading-tight line-clamp-2">{item.name}</h3>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-[10px] text-slate-400 font-medium">{item.owner}</p>
                    <div className="flex items-center gap-1">
                      <Star className="text-amber-400 fill-amber-400" size={10} />
                      <span className="text-[10px] font-bold text-slate-500">{item.rating}</span>
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <p className="syne-wide text-[16px] text-[#C07828] leading-none">{item.price}</p>
                  <div className="w-7 h-7 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                    <ChevronRight size={14} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center mt-12 text-center animate-fade">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mb-6">
              <Key size={40} strokeWidth={1} />
            </div>
            <h3 className="font-syne font-extrabold text-lg text-[#1B1916] mb-2 tracking-tight">No items available</h3>
            <p className="text-sm font-medium text-slate-400 px-8 leading-relaxed italic">Try a different category or check back later</p>
          </div>
        )}
      </div>

      {selected && <DetailSheet item={selected} onClose={() => setSelected(null)} />}
      
      {showList && (
        <FormSheet 
          title="🔑 List Item for Rent" 
          fields={listFields} 
          submitLabel="Publish Listing" 
          onClose={() => setShowList(false)} 
        />
      )}

      <BottomNav />
    </div>
  );
}
